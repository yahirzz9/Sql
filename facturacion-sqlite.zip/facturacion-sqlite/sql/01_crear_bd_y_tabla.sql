-- a) Base de datos: facturacion.db  |  Tabla: Clientes (8 campos)
CREATE TABLE IF NOT EXISTS Clientes (
    id_cliente     INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre         TEXT NOT NULL,
    apellido       TEXT NOT NULL,
    dni            TEXT NOT NULL UNIQUE,
    telefono       TEXT,
    email          TEXT,
    ciudad         TEXT,
    fecha_registro DATE
);
