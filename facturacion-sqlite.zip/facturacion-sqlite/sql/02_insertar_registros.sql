-- b) 12 registros
INSERT INTO Clientes (nombre, apellido, dni, telefono, email, ciudad, fecha_registro) VALUES
('Carlos',  'Quispe Mamani',   '45871236', '954123456', 'carlos.quispe@mail.com',  'Arequipa', '2026-01-10'),
('María',   'Flores Huamán',   '70234518', '987654321', 'maria.flores@mail.com',   'Cusco',    '2026-01-15'),
('Luis',    'Ramírez Torres',  '41236587', '965478123', 'luis.ramirez@mail.com',   'Lima',     '2026-02-03'),
('Ana',     'Condori Apaza',   '72145896', '951236478', 'ana.condori@mail.com',    'Arequipa', '2026-02-12'),
('Jorge',   'Salas Vargas',    '43125879', '944785213', 'jorge.salas@mail.com',    'Tacna',    '2026-03-01'),
('Lucía',   'Mendoza Ccori',   '74589632', '977845123', 'lucia.mendoza@mail.com',  'Arequipa', '2026-03-18'),
('Pedro',   'Huanca Paredes',  '40256987', '958741236', 'pedro.huanca@mail.com',   'Puno',     '2026-04-05'),
('Rosa',    'Chávez Díaz',     '46321598', '912365478', 'rosa.chavez@mail.com',    'Lima',     '2026-04-22'),
('Miguel',  'Cáceres Núñez',   '71236985', '936985214', 'miguel.caceres@mail.com', 'Cusco',    '2026-05-09'),
('Elena',   'Vilca Choque',    '48521369', '965874123', 'elena.vilca@mail.com',    'Arequipa', '2026-05-30'),
('Diego',   'Paredes Rojas',   '73698521', '987412365', 'diego.paredes@mail.com',  'Lima',     '2026-06-14'),
('Sofía',   'Gómez Linares',   '44785263', '954698712', 'sofia.gomez@mail.com',    'Tacna',    '2026-07-02');
