-- d) 3 eliminaciones
-- 1. Por clave primaria
DELETE FROM Clientes WHERE id_cliente = 12;
-- 2. Por DNI
DELETE FROM Clientes WHERE dni = '40256987';
-- 3. Por condición (ciudad)
DELETE FROM Clientes WHERE ciudad = 'Tacna';
