-- c) 5 consultas sencillas
-- 1. Todos los clientes
SELECT * FROM Clientes;
-- 2. Solo nombre, apellido y ciudad
SELECT nombre, apellido, ciudad FROM Clientes;
-- 3. Clientes de Arequipa
SELECT id_cliente, nombre, apellido, telefono FROM Clientes WHERE ciudad = 'Arequipa';
-- 4. Clientes ordenados por apellido
SELECT nombre, apellido, email FROM Clientes ORDER BY apellido ASC;
-- 5. Cantidad de clientes por ciudad
SELECT ciudad, COUNT(*) AS total_clientes FROM Clientes GROUP BY ciudad ORDER BY total_clientes DESC;
