-- a) Base de datos: facturacion.db  |  Tabla: Clientes (8 campos)
CREATE TABLE IF NOT EXISTS Clientes (
    id_cliente     INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre         TEXT NOT NULL,
    apellido       TEXT NOT NULL,
    dni            TEXT NOT NULL UNIQUE,
    telefono       TEXT,
    email          TEXT,
    ciudad         TEXT,
    fecha_registro DATE
);
-- b) 12 registros
INSERT INTO Clientes (nombre, apellido, dni, telefono, email, ciudad, fecha_registro) VALUES
('Carlos',  'Quispe Mamani',   '45871236', '954123456', 'carlos.quispe@mail.com',  'Arequipa', '2026-01-10'),
('María',   'Flores Huamán',   '70234518', '987654321', 'maria.flores@mail.com',   'Cusco',    '2026-01-15'),
('Luis',    'Ramírez Torres',  '41236587', '965478123', 'luis.ramirez@mail.com',   'Lima',     '2026-02-03'),
('Ana',     'Condori Apaza',   '72145896', '951236478', 'ana.condori@mail.com',    'Arequipa', '2026-02-12'),
('Jorge',   'Salas Vargas',    '43125879', '944785213', 'jorge.salas@mail.com',    'Tacna',    '2026-03-01'),
('Lucía',   'Mendoza Ccori',   '74589632', '977845123', 'lucia.mendoza@mail.com',  'Arequipa', '2026-03-18'),
('Pedro',   'Huanca Paredes',  '40256987', '958741236', 'pedro.huanca@mail.com',   'Puno',     '2026-04-05'),
('Rosa',    'Chávez Díaz',     '46321598', '912365478', 'rosa.chavez@mail.com',    'Lima',     '2026-04-22'),
('Miguel',  'Cáceres Núñez',   '71236985', '936985214', 'miguel.caceres@mail.com', 'Cusco',    '2026-05-09'),
('Elena',   'Vilca Choque',    '48521369', '965874123', 'elena.vilca@mail.com',    'Arequipa', '2026-05-30'),
('Diego',   'Paredes Rojas',   '73698521', '987412365', 'diego.paredes@mail.com',  'Lima',     '2026-06-14'),
('Sofía',   'Gómez Linares',   '44785263', '954698712', 'sofia.gomez@mail.com',    'Tacna',    '2026-07-02');
-- c) 5 consultas sencillas
-- 1. Todos los clientes
SELECT * FROM Clientes;
-- 2. Solo nombre, apellido y ciudad
SELECT nombre, apellido, ciudad FROM Clientes;
-- 3. Clientes de Arequipa
SELECT id_cliente, nombre, apellido, telefono FROM Clientes WHERE ciudad = 'Arequipa';
-- 4. Clientes ordenados por apellido
SELECT nombre, apellido, email FROM Clientes ORDER BY apellido ASC;
-- 5. Cantidad de clientes por ciudad
SELECT ciudad, COUNT(*) AS total_clientes FROM Clientes GROUP BY ciudad ORDER BY total_clientes DESC;
-- d) 3 eliminaciones
-- 1. Por clave primaria
DELETE FROM Clientes WHERE id_cliente = 12;
-- 2. Por DNI
DELETE FROM Clientes WHERE dni = '40256987';
-- 3. Por condición (ciudad)
DELETE FROM Clientes WHERE ciudad = 'Tacna';
