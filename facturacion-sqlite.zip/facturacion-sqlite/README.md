# Base de datos de facturación – SQLite

Ejercicio práctico con **DB Browser for SQLite**: creación de la BD `facturacion` con la tabla `Clientes`, inserción de registros, consultas y eliminaciones.

## Enunciado
1. Crear una BD *facturación* con la tabla **Clientes** (mínimo 5 campos).
2. Ingresar mínimo **10 registros**.
3. Realizar **5 consultas** sencillas.
4. Realizar **3 eliminaciones**.

## Estructura del repositorio
```
├── facturacion.db                 # Base de datos resultante (estado final)
├── facturacion_completo.sql       # Script completo (se puede ejecutar de una vez)
├── sql/
│   ├── 01_crear_bd_y_tabla.sql
│   ├── 02_insertar_registros.sql
│   ├── 03_consultas.sql
│   └── 04_eliminaciones.sql
├── capturas/                      # Capturas de cada paso
├── generar_capturas.py            # Script que ejecuta el SQL y genera las capturas
└── Informe_Ejercicio_SQLite.docx  # Informe explicado paso a paso
```

## Tabla `Clientes`
| Campo | Tipo | Descripción |
|---|---|---|
| id_cliente | INTEGER PK AUTOINCREMENT | Identificador único |
| nombre | TEXT NOT NULL | Nombres |
| apellido | TEXT NOT NULL | Apellidos |
| dni | TEXT NOT NULL UNIQUE | Documento de identidad |
| telefono | TEXT | Teléfono |
| email | TEXT | Correo electrónico |
| ciudad | TEXT | Ciudad |
| fecha_registro | DATE | Fecha de alta |

## Cómo usarlo
1. Abrir **DB Browser for SQLite** → *Nueva base de datos* → `facturacion.db`.
2. Pestaña **Ejecutar SQL** → abrir y ejecutar los archivos de `sql/` en orden (01 → 04), o `facturacion_completo.sql`.
3. O por terminal: `sqlite3 facturacion.db < facturacion_completo.sql`

## Consultas (c)
1. `SELECT * FROM Clientes;`
2. `SELECT nombre, apellido, ciudad FROM Clientes;`
3. `... WHERE ciudad = 'Arequipa';`
4. `... ORDER BY apellido ASC;`
5. `SELECT ciudad, COUNT(*) ... GROUP BY ciudad;`

## Eliminaciones (d)
1. Por clave primaria (`id_cliente = 12`)
2. Por DNI único
3. Por condición (`ciudad = 'Tacna'`)

Resultado: 12 registros iniciales → **9** finales.
