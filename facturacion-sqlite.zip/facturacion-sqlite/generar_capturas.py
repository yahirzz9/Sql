"""Ejecuta el SQL sobre facturacion.db y renderiza los resultados como imágenes."""
import sqlite3, os
from PIL import Image, ImageDraw, ImageFont
F="/usr/share/fonts/truetype/dejavu/"
sans=ImageFont.truetype(F+"DejaVuSans.ttf",15); bold=ImageFont.truetype(F+"DejaVuSans-Bold.ttf",15)
mono=ImageFont.truetype(F+"DejaVuSansMono.ttf",15)
if os.path.exists("facturacion.db"): os.remove("facturacion.db")
db=sqlite3.connect("facturacion.db")
def run(sql):
    cur=db.execute(sql); db.commit()
    return ([d[0] for d in cur.description], cur.fetchall()) if cur.description else None
def render(path, title, sql, result=None, msg=None):
    cols,rows=result if result else ([],[])
    tw=ImageDraw.Draw(Image.new("RGB",(1,1))).textlength
    widths=[max([tw(c,bold)]+[tw(str(r[i]),sans) for r in rows])+24 for i,c in enumerate(cols)]
    lines=sql.split("\n"); W=int(max(900,sum(widths)+40, max(tw(l,mono) for l in lines)+60))
    rh=26; h=40+30+len(lines)*22+20+(40+rh*(len(rows)+1)+10 if cols else 0)+(34 if msg else 0)+20
    im=Image.new("RGB",(W,h),"#f0f0f0"); d=ImageDraw.Draw(im)
    d.rectangle([0,0,W,32],fill="#2b5d8a"); d.text((12,7),"DB Browser for SQLite - facturacion.db  |  "+title,font=bold,fill="white")
    y=44; d.text((12,y),"Ejecutar SQL",font=bold,fill="#333"); y+=26
    d.rectangle([10,y,W-10,y+len(lines)*22+10],fill="white",outline="#aaa")
    for i,l in enumerate(lines):
        d.text((46,y+5+i*22),l,font=mono,fill="#0b3d91"); d.text((16,y+5+i*22),str(i+1),font=mono,fill="#999")
    y+=len(lines)*22+20
    if cols:
        d.rectangle([10,y,W-10,y+rh*(len(rows)+1)+4],fill="white",outline="#aaa"); x0=14
        x=x0
        for c,w in zip(cols,widths):
            d.rectangle([x,y+2,x+w,y+rh],fill="#e4e4e4",outline="#bbb"); d.text((x+8,y+6),c,font=bold,fill="#222"); x+=w
        for ri,r in enumerate(rows):
            x=x0; yy=y+2+rh*(ri+1)
            if ri%2: d.rectangle([x0,yy,x0+sum(widths),yy+rh],fill="#f6f9fc")
            for v,w in zip(r,widths): d.text((x+8,yy+5),str(v),font=sans,fill="#111"); x+=w
        y+=rh*(len(rows)+1)+14
    if msg: d.text((12,y+4),msg,font=sans,fill="#1a7f37")
    im.save("capturas/"+path)
def exe(sql): 
    try: return run(sql)
    except Exception as e: raise
S=open("sql/01_crear_bd_y_tabla.sql").read(); exe(S)
cols,rows=run("PRAGMA table_info(Clientes)")
render("01_estructura_tabla.png","Estructura de la base de datos","\n".join(S.strip().split("\n")[1:]),
       (["cid","name","type","notnull","dflt_value","pk"],rows),"Ejecución finalizada sin errores. Tabla Clientes creada con 8 campos.")
I=open("sql/02_insertar_registros.sql").read(); exe(I)
render("02_datos_insertados.png","Navegar datos: Clientes","SELECT * FROM Clientes;",run("SELECT * FROM Clientes"),"12 filas devueltas - se insertaron 12 registros (mínimo exigido: 10).")
Q=[("03_consulta1_todos.png","Consulta 1","SELECT * FROM Clientes;"),
("04_consulta2_columnas.png","Consulta 2","SELECT nombre, apellido, ciudad FROM Clientes;"),
("05_consulta3_where.png","Consulta 3","SELECT id_cliente, nombre, apellido, telefono\nFROM Clientes\nWHERE ciudad = 'Arequipa';"),
("06_consulta4_orderby.png","Consulta 4","SELECT nombre, apellido, email\nFROM Clientes\nORDER BY apellido ASC;"),
("07_consulta5_groupby.png","Consulta 5","SELECT ciudad, COUNT(*) AS total_clientes\nFROM Clientes\nGROUP BY ciudad\nORDER BY total_clientes DESC;")]
for f,t,q in Q:
    r=run(q); render(f,t,q,r,f"{len(r[1])} filas devueltas.")
D=[("08_eliminacion1.png","Eliminación 1","DELETE FROM Clientes WHERE id_cliente = 12;"),
("09_eliminacion2.png","Eliminación 2","DELETE FROM Clientes WHERE dni = '40256987';"),
("10_eliminacion3.png","Eliminación 3","DELETE FROM Clientes WHERE ciudad = 'Tacna';")]
for f,t,q in D:
    n=db.execute(q).rowcount; db.commit()
    render(f,t,q+"\nSELECT id_cliente, nombre, apellido, ciudad FROM Clientes;",run("SELECT id_cliente, nombre, apellido, ciudad FROM Clientes"),f"Consulta ejecutada: {n} fila(s) afectada(s). Quedan {db.execute('select count(*) from Clientes').fetchone()[0]} registros.")
render("11_resultado_final.png","Estado final","SELECT * FROM Clientes;",run("SELECT * FROM Clientes"),"9 filas devueltas - estado final tras las 3 eliminaciones.")
